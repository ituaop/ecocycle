<?php

namespace Src\Recycling\User\Domain\ValueObjects;

class UserTotalPoints
{

}
