<?php

namespace Src\Recycling\User\Domain\Enumerations;

enum UserLevelEnumeration
{

}
