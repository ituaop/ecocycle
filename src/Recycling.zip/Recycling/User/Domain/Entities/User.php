<?php

namespace Src\Recycling\User\Domain\Entities;

class User
{

}
