export interface User {
    id: string;
    name: string;
    email: string;
    email_verified_at: string | null;
    total_points: number;
    level: string;
}

export type PageProps<
    T extends Record<string, unknown> = Record<string, unknown>,
> = T & {
    auth: {
        user: User;
    };
};
